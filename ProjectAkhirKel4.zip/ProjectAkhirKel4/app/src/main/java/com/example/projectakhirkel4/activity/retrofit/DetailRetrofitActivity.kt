package com.example.projectakhirkel4.activity.retrofit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.projectakhirkel4.R
import com.example.projectakhirkel4.data.PracticeAPIResponse
import com.google.android.material.imageview.ShapeableImageView

class DetailRetrofitActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_retrofit)

        val getData = intent.getParcelableExtra<PracticeAPIResponse>("playerAPI")!!

        val dataNama = findViewById<TextView>(R.id.name)
        val dataAlamat = findViewById<TextView>(R.id.alamat)
        val dataLayanan = findViewById<TextView>(R.id.data_layanan)
        val dataFasilitas = findViewById<TextView>(R.id.data_fasilitas)
        val dataJumlahPekerja = findViewById<TextView>(R.id.data_jmlpekerja)
        val dataJam = findViewById<TextView>(R.id.data_jam)
        val dataKunjungan = findViewById<TextView>(R.id.data_kunjungan)
        val dataContact = findViewById<TextView>(R.id.data_notelp)

        dataNama.text = getData.nama
        dataAlamat.text = getData.alamat
        dataLayanan.text = getData.layanan
        dataFasilitas.text = getData.fasilitas
        dataJumlahPekerja.text = getData.jmlpekerja
        dataJam.text = getData.jamoperasional
        dataKunjungan.text = getData.kunjungan
        dataContact.text = getData.notelp


    }
}