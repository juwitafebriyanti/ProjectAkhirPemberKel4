package com.example.projectakhirkel4.activity.retrofit

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.projectakhirkel4.R
import com.example.projectakhirkel4.adapter.PracticeAdapter
import com.example.projectakhirkel4.data.PracticeAPIResponse
import com.example.projectakhirkel4.data.PracticeViewModel
import com.example.projectakhirkel4.data.PracticeViewModelFactory


class DataRetrofitActivity : AppCompatActivity() {
    private lateinit var practiceViewModel: PracticeViewModel
    private lateinit var adapter: PracticeAdapter
    private lateinit var recyclerView: RecyclerView


    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_retrofit)

        val factory = PracticeViewModelFactory.getInstance()
        practiceViewModel = ViewModelProvider(this, factory)[PracticeViewModel::class.java]

        recyclerView = findViewById(R.id.rv_retrofit)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = PracticeAdapter(emptyList()) // Initialize with an empty list
        recyclerView.adapter = adapter


        practiceViewModel.getAllData()

        practiceViewModel.listData.observe(this) { listPlayer ->

            if (listPlayer.isNotEmpty()) {

                adapter = PracticeAdapter(listPlayer)
                recyclerView.adapter = adapter

                adapter.setOnItemClickCallback(object : PracticeAdapter.OnItemClickCallback {
                    override fun onItemClicked(data: PracticeAPIResponse) {
                        showSelectedPlayer(data)
                    }
                })
            }
        }

        practiceViewModel.listData.observe(this) { player ->
            if (player != null) {
                practiceViewModel.getAllData()
            }
        }

        practiceViewModel.isLoading.observe(this) {
            showLoading(it)
        }

    }

    private fun showLoading(isLoading: Boolean) {
        val loading = findViewById<ProgressBar>(R.id.progressBar)
        loading.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun showSelectedPlayer(data: PracticeAPIResponse) {
        val navigateToDetail = Intent(this, DetailRetrofitActivity::class.java)

        navigateToDetail.putExtra("playerAPI", data)

        startActivity(navigateToDetail)
    }
}