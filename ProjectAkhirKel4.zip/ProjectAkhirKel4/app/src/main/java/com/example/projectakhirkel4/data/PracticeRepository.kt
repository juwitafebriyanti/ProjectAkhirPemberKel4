package com.example.projectakhirkel4.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PracticeRepository {
    val _listData = MutableLiveData<List<PracticeAPIResponse>>()
    val listPlayer: LiveData<List<PracticeAPIResponse>> = _listData

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun getAllData() {
        _isLoading.value = true
        val service = PracticeAPIConfig.getApiService().getAllData()
        service.enqueue(object : Callback<List<PracticeAPIResponse>> {
            override fun onResponse(
                call: Call<List<PracticeAPIResponse>>,
                response: Response<List<PracticeAPIResponse>>
            ) {
                _isLoading.value = false

                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    _listData.value = responseBody!!
                } else {
                    Log.e("Error on Response", "onResponse: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<PracticeAPIResponse>>, t: Throwable) {
                _isLoading.value = false
                Log.e("Error on Failure", "onFailure: ${t.message}")
            }
        })
    }
}