package com.example.projectakhirkel4.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface RoomDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertRoom(roomEntity: RoomEntity)

    @Query("SELECT * FROM roomentity ORDER BY name ASC")
    fun getAllRoom() : LiveData<List<RoomEntity>>

    @Update
    fun updateRoom(roomEntity: RoomEntity)

    @Delete
    fun deleteRoom(roomEntity: RoomEntity)
}
