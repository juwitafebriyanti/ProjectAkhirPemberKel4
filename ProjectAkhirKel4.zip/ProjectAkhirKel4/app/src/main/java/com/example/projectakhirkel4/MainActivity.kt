package com.example.projectakhirkel4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.projectakhirkel4.activity.retrofit.DataRetrofitActivity
import com.example.projectakhirkel4.activity.room.AddRoomActivity
import com.example.projectakhirkel4.activity.room.DetailRoomActivity
import com.example.projectakhirkel4.activity.room.PopUpPractice
import com.example.projectakhirkel4.adapter.AdapterRoom
import com.example.projectakhirkel4.room.RoomEntity
import com.example.projectakhirkel4.room.RoomViewModel
import com.example.projectakhirkel4.room.RoomViewModelFactory
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private lateinit var appViewModel: RoomViewModel
    private lateinit var adapterRoom: AdapterRoom
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val getDataName = intent.getStringExtra("name")

        val displayTitle = findViewById<TextView>(R.id.greeting_text)
        displayTitle.text = "Halo, $getDataName"

        val factory = RoomViewModelFactory.getInstance(this)
        appViewModel = ViewModelProvider(this, factory)[RoomViewModel::class.java]

        recyclerView = findViewById(R.id.rv_player_room)
        recyclerView.layoutManager = LinearLayoutManager(this)

        appViewModel.getAllRoom().observe(this) { roomData ->
            if (roomData != null) {
                adapterRoom = AdapterRoom(roomData)
                recyclerView.adapter = adapterRoom

                adapterRoom.setOnItemClickCallback(object :
                    AdapterRoom.OnItemClickCallback {
                    override fun onItemClicked(data: RoomEntity) {
                        showSelectedPlayer(data)
                    }

                    override fun onItemMore(data: RoomEntity) {
                        PopUpPractice(data).show(supportFragmentManager, PopUpPractice.TAG)
                    }
                })
            }
        }

        val btnAdd = findViewById<FloatingActionButton>(R.id.btn_add_player)
        btnAdd.setOnClickListener {
            val intent = Intent(this, AddRoomActivity::class.java)
            startActivity(intent)
        }

        val retrofitActivity = findViewById<ImageView>(R.id.navigate_room)
        retrofitActivity.setOnClickListener {
            val intent = Intent(this, DataRetrofitActivity::class.java)
            startActivity(intent)
        }

        val profil = findViewById<ImageView>(R.id.profil)
        profil.setOnClickListener {
            val intent = Intent(this, ProfilActivity::class.java)
            ContextCompat.startActivity(this, intent, null)
        }
    }

    private fun showSelectedPlayer(data: RoomEntity) {
        val navigateToDetail = Intent(this, DetailRoomActivity::class.java)

        navigateToDetail.putExtra("data", data)

        navigateToDetail.putExtra("name", data.name)
        navigateToDetail.putExtra("description", data.description)

        startActivity(navigateToDetail)
    }

    override fun onRestart() {
        super.onRestart()

        appViewModel.getAllRoom()
    }
}