package com.example.projectakhirkel4.room

import androidx.lifecycle.LiveData
import com.example.projectakhirkel4.utils.AppExecutors

class RoomRepository  private constructor(private val appDao: RoomDao, private val appExecutors: AppExecutors) {

    fun getAllRoom(): LiveData<List<RoomEntity>> = appDao.getAllRoom()

    fun insertRoom(roomEntity: RoomEntity) {
        appExecutors.diskIO().execute { appDao.insertRoom(roomEntity) }
    }

    fun updateRoom(roomEntity: RoomEntity){
        appExecutors.diskIO().execute { appDao.updateRoom(roomEntity) }
    }

    fun deleteRoom(roomEntity: RoomEntity){
        appExecutors.diskIO().execute { appDao.deleteRoom(roomEntity) }
    }

    companion object {
        @Volatile
        private var instance: RoomRepository? = null

        fun getInstance(
            appDao: RoomDao,
            appExecutors: AppExecutors
        ): RoomRepository =
            instance ?: synchronized(this) {
                instance ?: RoomRepository(appDao, appExecutors)
            }.also { instance = it }
    }
}