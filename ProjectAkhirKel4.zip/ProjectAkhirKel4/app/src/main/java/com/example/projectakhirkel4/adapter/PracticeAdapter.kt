package com.example.projectakhirkel4.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.projectakhirkel4.R
import com.example.projectakhirkel4.data.PracticeAPIResponse

class PracticeAdapter(private var players: List<PracticeAPIResponse>) :
    RecyclerView.Adapter<PracticeAdapter.ViewHolder>() {

    interface OnItemClickCallback {
        fun onItemClicked(data: PracticeAPIResponse)
    }

    private lateinit var onItemClickCallback: OnItemClickCallback

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val datanama: TextView = itemView.findViewById(R.id.name)
        val dataalamat: TextView = itemView.findViewById(R.id.alamat)
        val datalayanan: TextView = itemView.findViewById(R.id.layanan)
        val datajam: TextView = itemView.findViewById(R.id.jam)
        val backgroundImage: ImageView = itemView.findViewById(R.id.background_image)
    }

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.activity_data_api, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = players[position]
        holder.datanama.text = data.nama
        holder.dataalamat.text = data.alamat
        holder.datalayanan.text = data.layanan
        holder.datajam.text = data.jamoperasional

        Glide.with(holder.backgroundImage.context)
            .load(R.drawable.bg3) // Ganti dengan ID resource dari gambar drawable
            .into(holder.backgroundImage)


        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(players[holder.adapterPosition]) }
    }

    override fun getItemCount(): Int = players.size

    private fun String.shorten(maxLength: Int): String {
        return if (this.length <= maxLength) this else "${this.substring(0, maxLength)}..."
    }
}
