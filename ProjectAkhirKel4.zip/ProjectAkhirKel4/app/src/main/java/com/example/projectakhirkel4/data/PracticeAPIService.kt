package com.example.projectakhirkel4.data

import retrofit2.Call
import retrofit2.http.GET

interface PracticeAPIService {
    @GET("daftarrs")
    fun getAllData(): Call<List<PracticeAPIResponse>>
}