package com.example.projectakhirkel4.adapter

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.projectakhirkel4.R
import com.example.projectakhirkel4.room.RoomEntity
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.textview.MaterialTextView

class AdapterRoom (private var dataList: List<RoomEntity>) :
    RecyclerView.Adapter<AdapterRoom.PeopleViewHolder>() {

    // Deklarasi variabel untuk callback ketika item diklik
    private lateinit var onItemClickCallback: OnItemClickCallback

    // Fungsi untuk mengatur callback ketika item diklik
    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    // Interface untuk callback ketika item diklik
    interface OnItemClickCallback {
        fun onItemClicked(data: RoomEntity)
        fun onItemMore(data: RoomEntity)
    }

    // Kelas ViewHolder untuk menyimpan referensi view yang digunakan dalam RecyclerView
    class PeopleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val dataName: MaterialTextView = itemView.findViewById(R.id.data_name)
        val dataDescription: MaterialTextView = itemView.findViewById(R.id.data_description)
        val dataImage: ShapeableImageView = itemView.findViewById(R.id.data_image)
        val loveImageView: ImageView = itemView.findViewById(R.id.imageView2)
        val likeTextView: TextView = itemView.findViewById(R.id.like)
        val komenView: ImageView = itemView.findViewById(R.id.imageView3)
        val btnkomen: TextView = itemView.findViewById(R.id.komen)
        val btnMore: ImageView = itemView.findViewById(R.id.btn_more)
    }

    // Fungsi untuk membuat ViewHolder (Melakukan setting untuk XML yang akan kita gunakan untuk menampilkan data)
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): PeopleViewHolder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.activity_data_room, parent, false)
        return PeopleViewHolder(view)
    }

    // Fungsi untuk mengikat data dengan ViewHolder (memasukkan data yang kita miliki ke dalam XML ViewHolder)
    override fun onBindViewHolder(holder: PeopleViewHolder, position: Int) {
        val data = dataList[position]

        holder.dataName.text = data.name
        holder.dataDescription.text = data.description.shorten(85)

        // Mengatur image
        val uri = Uri.fromFile(data.image)
        holder.dataImage.setImageURI(uri)

        // Mengatur aksi ketika item diklik
        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(dataList[holder.absoluteAdapterPosition]) }

        // Mengatur aksi ketika button more diklik
        holder.btnMore.setOnClickListener { onItemClickCallback.onItemMore(dataList[holder.absoluteAdapterPosition]) }

        // Mengatur aksi ketika like diklik
        holder.loveImageView.setOnClickListener {
            var likeCount = holder.likeTextView.text.toString().toInt()
            likeCount++
            holder.likeTextView.text = likeCount.toString()
        }

        // Mengatur aksi ketika komen diklik
        holder.komenView.setOnClickListener {
            var komen = holder.btnkomen.text.toString().toInt()
            komen++
            holder.btnkomen.text = komen.toString()
        }
    }

    // Fungsi untuk mendapatkan jumlah item
    override fun getItemCount(): Int = dataList.size

    // Fungsi untuk memendekkan teks jika melebihi panjang maksimum
    private fun String.shorten(maxLength: Int): String {
        return if (this.length <= maxLength) this else "${this.substring(0, maxLength)}..."
    }
}