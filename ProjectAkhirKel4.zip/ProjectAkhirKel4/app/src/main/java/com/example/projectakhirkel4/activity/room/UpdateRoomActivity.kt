package com.example.projectakhirkel4.activity.room

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.esafirm.imagepicker.features.ImagePickerConfig
import com.esafirm.imagepicker.features.ImagePickerMode
import com.esafirm.imagepicker.features.ReturnMode
import com.esafirm.imagepicker.features.registerImagePicker
import com.example.projectakhirkel4.R
import com.example.projectakhirkel4.room.RoomEntity
import com.example.projectakhirkel4.room.RoomViewModel
import com.example.projectakhirkel4.room.RoomViewModelFactory
import com.example.projectakhirkel4.utils.reduceFileImage
import com.example.projectakhirkel4.utils.uriToFile
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.io.File

class UpdateRoomActivity : AppCompatActivity() {
    private var currentImageUri: Uri? = null
    private var oldPhoto: File? = null
    private lateinit var playerImage: ImageView
    private lateinit var peopleViewModel: RoomViewModel
    private lateinit var playerName: TextInputEditText
    private lateinit var playerDescription: TextInputEditText
    private lateinit var playerImageInput: TextInputEditText
    private lateinit var getDataPeople: RoomEntity

    private val imagePickerLauncher = registerImagePicker {
        val firstImage = it.firstOrNull() ?: return@registerImagePicker
        if (firstImage.uri.toString().isNotEmpty()) {
            playerImage.visibility = View.VISIBLE
            currentImageUri = firstImage.uri
            Glide.with(playerImage)
                .load(firstImage.uri)
                .into(playerImage)
        } else {
            playerImage.visibility = View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_room)

        getDataPeople = intent.getParcelableExtra("data")!!

        val factory = RoomViewModelFactory.getInstance(this)
        peopleViewModel = ViewModelProvider(this, factory)[RoomViewModel::class.java]

        playerImage = findViewById(R.id.player_image)
        playerName = findViewById(R.id.player_name_edit)
        playerDescription = findViewById(R.id.player_desc_edit)
        playerImageInput = findViewById(R.id.people_image)

        playerName.setText(getDataPeople!!.name)
        playerDescription.setText(getDataPeople!!.description)
        Glide.with(this)
            .load(getDataPeople.image)
            .into(playerImage)

        oldPhoto = getDataPeople.image

        onClick()
    }

    private fun onClick() {
        val savedBtn = findViewById<MaterialButton>(R.id.saved_player)
        savedBtn.setOnClickListener {
            if (validateInput()) {
                savedData()
            }
        }

        val openImagePicker = findViewById<TextInputEditText>(R.id.people_image)
        openImagePicker.setOnClickListener {
            imagePickerLauncher.launch(
                ImagePickerConfig {
                    mode = ImagePickerMode.SINGLE
                    returnMode = ReturnMode.ALL
                    isFolderMode = true
                    folderTitle = "Galeri"
                    isShowCamera = false
                    imageTitle = "Tekan untuk memilih gambar"
                    doneButtonText = "Selesai"
                }
            )
        }
    }

    private fun validateInput(): Boolean {
        var error = 0

        if (playerName.text.toString().isEmpty()) {
            error++
            playerName.error = "Judul tidak boleh kosong"
        }

        if (playerDescription.text.toString().isEmpty()) {
            error++
            playerDescription.error = "Deskripsi tidak boleh kosong"
        }

        if (playerImageInput.text.toString().isEmpty()) {
            error++
            playerImageInput.error = "Gambar tidak boleh kosong"
        }

        return error == 0
    }

    private fun savedData() {
        val imageFile = currentImageUri?.let { uriToFile(it, this).reduceFileImage() }

        val roomEntity = (if (currentImageUri != null) imageFile else oldPhoto)?.let {
            RoomEntity(
                id = getDataPeople.id,
                name = playerName.text.toString(),
                description = playerDescription.text.toString(),
                image = it,
                likeCount = 0,
                komen = 0
            )
        }

        Log.d("data", roomEntity.toString())

        if (roomEntity != null) peopleViewModel.updateRoom(roomEntity)

        Toast.makeText(
            this@UpdateRoomActivity,
            "Data berhasil diubah",
            Toast.LENGTH_SHORT
        ).show()

        finish()
    }
}