package com.example.projectakhirkel4.data

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

data class PracticeAPIResponse (
    @field:SerializedName("nama")
    val nama: String,

    @field:SerializedName("alamat")
    val alamat: String,

    @field:SerializedName("notelp")
    val notelp: String,

    @field:SerializedName("jamoperasional")
    val jamoperasional: String,

    @field:SerializedName("fasilitas")
    val fasilitas: String,

    @field:SerializedName("layanan")
    val layanan: String,

    @field:SerializedName("jmlpekerja")
    val jmlpekerja: String,

    @field:SerializedName("kunjungan")
    val kunjungan: String,

    @field:SerializedName("id")
    val id: Int
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readInt()
    )

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(nama)
        dest.writeString(alamat)
        dest.writeString(notelp)
        dest.writeString(jamoperasional)
        dest.writeString(fasilitas)
        dest.writeString(layanan)
        dest.writeString(jmlpekerja)
        dest.writeString(kunjungan)
        dest.writeInt(id)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<PracticeAPIResponse> {
        override fun createFromParcel(source: Parcel): PracticeAPIResponse {
            return PracticeAPIResponse(source)
        }

        override fun newArray(size: Int): Array<PracticeAPIResponse?> {
            return arrayOfNulls(size)
        }
    }
}