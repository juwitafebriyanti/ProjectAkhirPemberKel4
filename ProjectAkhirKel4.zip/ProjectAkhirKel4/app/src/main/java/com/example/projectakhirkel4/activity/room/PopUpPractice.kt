package com.example.projectakhirkel4.activity.room

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.core.view.updateLayoutParams
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProvider
import com.example.projectakhirkel4.R
import com.example.projectakhirkel4.room.RoomEntity
import com.example.projectakhirkel4.room.RoomViewModel
import com.example.projectakhirkel4.room.RoomViewModelFactory
import com.google.android.material.button.MaterialButton

class PopUpPractice (private val roomEntity: RoomEntity) : DialogFragment() {

    private lateinit var appViewModel: RoomViewModel

    override fun getTheme(): Int {
        return R.style.DialogTheme
    }

    override fun onStart() {
        super.onStart()
        requireDialog().window?.apply {
            setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        view?.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            setMargins(16, 16, 16, 16)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.activity_pop_up_practice, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val factory = RoomViewModelFactory.getInstance(requireContext())
        appViewModel = ViewModelProvider(this, factory)[RoomViewModel::class.java]

        val btnUbah: MaterialButton = view.findViewById(R.id.btn_ubah)
        val btnHapus: MaterialButton = view.findViewById(R.id.btn_hapus)

        btnUbah.setOnClickListener {
            val intent = Intent(requireContext(), UpdateRoomActivity::class.java)
            intent.putExtra("data", roomEntity)
            startActivity(intent)
            dismiss()
        }

        btnHapus.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Konfirmasi")
                .setMessage("Yakin ingin menghapus item ini?")
                .setPositiveButton("Ya") { dialog, which ->
                    appViewModel.deleteRoom(roomEntity)
                    dismiss()
                }
                .setNegativeButton("Tidak", null)
                .show()
        }
    }

    companion object {
        const val TAG = "PopUpPracticeFragment"
    }

}