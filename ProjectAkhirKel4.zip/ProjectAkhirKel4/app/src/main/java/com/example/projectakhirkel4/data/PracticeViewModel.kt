package com.example.projectakhirkel4.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class PracticeViewModel (private val practiceRepository: PracticeRepository) : ViewModel() {

    val listData: MutableLiveData<List<PracticeAPIResponse>> = practiceRepository._listData

    val isLoading: LiveData<Boolean> = practiceRepository.isLoading

    fun getAllData() {
        practiceRepository.getAllData()
    }
}