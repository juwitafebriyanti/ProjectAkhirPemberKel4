package com.example.projectakhirkel4.utils

import android.content.Context
import com.example.projectakhirkel4.room.AppDatabase
import com.example.projectakhirkel4.room.RoomRepository

object DependencyInjection {
    fun provideRepository(context: Context): RoomRepository {
        val database = AppDatabase.getDatabase(context)
        val appExecutors = AppExecutors()
        val dao = database.RoomDao()
        return RoomRepository.getInstance(dao, appExecutors)
    }
}