package com.example.projectakhirkel4.activity.room

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.example.projectakhirkel4.R
import com.example.projectakhirkel4.room.RoomEntity
import com.google.android.material.imageview.ShapeableImageView
import java.io.ByteArrayOutputStream

class DetailRoomActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_room)

        val getDataName = intent.getStringExtra("name")
        val getDataDescription = intent.getStringExtra("description")
        val getDataImage = intent.getIntExtra("image", 0)

        val getDataRoom = intent.getParcelableExtra<RoomEntity>("data")

        val dataName = findViewById<TextView>(R.id.player_name)
        val dataDescription = findViewById<TextView>(R.id.player_description)
        val dataImage = findViewById<ShapeableImageView>(R.id.player_image)

        when {

            getDataRoom != null -> {
                dataName.text = getDataRoom.name
                dataDescription.text = getDataRoom.description
                Glide.with(dataImage)
                    .load(getDataRoom.image)
                    .into(dataImage)

            }

            else -> {
                dataName.text = getDataName
                dataDescription.text = getDataDescription
                dataImage.setImageResource(getDataImage)
            }
        }

        val btnShare = findViewById<ImageButton>(R.id.bagikan_btn)

        btnShare.setOnClickListener {

            val drawable = dataImage.drawable
            if (drawable != null) {
                val bitmap = (drawable as BitmapDrawable).bitmap
                val uri = getImageUri(bitmap)

                val sendIntent: Intent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, "Judul: $getDataName\nDeskripsi: $getDataDescription")
                    putExtra(Intent.EXTRA_STREAM, uri)
                    type = "image/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }

                val whatsappInstalled = isPackageInstalled("com.whatsapp") || isPackageInstalled("com.whatsapp.w4b")
                if (whatsappInstalled) {

                    sendIntent.setPackage("com.whatsapp")
                    startActivity(sendIntent)
                } else {

                    Toast.makeText(this, "WhatsApp tidak terinstal.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun isPackageInstalled(packageName: String): Boolean {
        return try {
            packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun getImageUri(bitmap: Bitmap): Uri {
        val bytes = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val path = MediaStore.Images.Media.insertImage(contentResolver, bitmap, "Temp Image", null)
        return Uri.parse(path)
    }
}