package com.example.projectakhirkel4.room

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel

class RoomViewModel (private val appRepository: RoomRepository) : ViewModel() {

    fun insertRoom(roomEntity: RoomEntity) {
        appRepository.insertRoom(roomEntity)
    }

    fun getAllRoom(): LiveData<List<RoomEntity>> {
        return appRepository.getAllRoom()
    }

    fun updateRoom(roomEntity: RoomEntity){
        appRepository.updateRoom(roomEntity)
    }

    fun deleteRoom(roomEntity: RoomEntity){
        appRepository.deleteRoom(roomEntity)
    }
}
